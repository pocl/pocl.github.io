==================
PoCL extensions
==================

PoCL currently supports one extension, cl_pocl_content_size.

cl_pocl_content_size
~~~~~~~~~~~~~~~~~~~~~~~

This extension provides a way to to indicate
a buffer which will hold the meaningful
bytes of another buffer, after kernel execution.

Full specification can be found on:

https://www.khronos.org/registry/OpenCL/
