Notes on internal design
===========================

Higher-level notes of pocl software design and implementation are collected 
to this part.

.. toctree::
   :maxdepth: 2

   host_library
   kernel_compiler
   memory_management
   pocl_binary
