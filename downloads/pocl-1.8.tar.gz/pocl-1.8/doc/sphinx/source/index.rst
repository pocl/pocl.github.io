.. Portable Computing Language (pocl) documentation master file, created by
   sphinx-quickstart on Fri May  3 10:53:18 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Portable Computing Language (pocl)'s documentation!
==============================================================

Contents:

.. toctree::
   :maxdepth: 2

   install
   using
   features
   debug
   faq
   development
   design

Back to `pocl home page <http://pocl.sourceforge.net>`_.

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

