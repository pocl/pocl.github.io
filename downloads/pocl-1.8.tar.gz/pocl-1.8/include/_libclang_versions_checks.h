#if CLANG_MAJOR < 14
#define LLVM_OLDER_THAN_14_0 1
#endif

#if CLANG_MAJOR < 13
#define LLVM_OLDER_THAN_13_0 1
#endif

#if CLANG_MAJOR < 12
#define LLVM_OLDER_THAN_12_0 1
#endif

#if CLANG_MAJOR < 11
#define LLVM_OLDER_THAN_11_0 1
#endif

#if CLANG_MAJOR < 10
#define LLVM_OLDER_THAN_10_0 1
#endif

#if CLANG_MAJOR < 9
#define LLVM_OLDER_THAN_9_0 1
#endif

#if CLANG_MAJOR < 8
#define LLVM_OLDER_THAN_8_0 1
#endif

#if CLANG_MAJOR < 7
#define LLVM_OLDER_THAN_7_0 1
#endif

#if CLANG_MAJOR < 6
#define LLVM_OLDER_THAN_6_0 1
#endif
