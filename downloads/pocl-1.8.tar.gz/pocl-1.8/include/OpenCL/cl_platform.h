#include "../CL/cl_platform.h"
