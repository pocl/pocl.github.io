/* Empty source file to keep "ar" happy */
